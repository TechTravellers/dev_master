<?php
$hostname = 'localhost';

$hostlogin = 'root';
$hostpassword = '';
$databasename = 'techtraveller';

$con=mysqli_connect($hostname,$hostlogin,$hostpassword,$databasename);




?>