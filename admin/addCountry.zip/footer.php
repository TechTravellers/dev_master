<div class="copyrights">
	 <p>© 2017 TechTraveller. All Rights Reserved <!--| Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a>--> </p>
</div>	
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>