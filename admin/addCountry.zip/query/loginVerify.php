<?php 

if($_SESSION['userId']==''){
	echo "<script>
			window.location='index.php';
		</script>";
}






?>